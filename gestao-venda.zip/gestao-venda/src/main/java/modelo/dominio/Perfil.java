package modelo.dominio;


public enum Perfil {
    ADMIN,
    PADRAO
    
}
