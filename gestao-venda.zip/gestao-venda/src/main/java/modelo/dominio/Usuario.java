package modelo.dominio;

import java.time.LocalDateTime;
import java.util.Objects;

public class Usuario {

    //Variáveis
    
    private Long id;
    private String nome;
    private String usuario;
    private String senha;
    private Perfil perfil;
    private boolean situacao;
    private LocalDateTime data_hora_criacao;
    private LocalDateTime ultimo_login;

    public Usuario() {
        this.situacao = true;
        
    }
    
    //CONSTRUTOR

    public Usuario(Long id, String nome, String usuario, String senha, Perfil perfil, LocalDateTime data_hora_criacao, LocalDateTime ultimo_login) {
        this.id = id;
        this.nome = nome;
        this.usuario = usuario;
        this.senha = senha;
        this.perfil = perfil;
        this.data_hora_criacao = data_hora_criacao;
        this.ultimo_login = ultimo_login;
        this.situacao = true;
    }

    //GET
    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getSenha() {
        return senha;
    }

    public Perfil getPerfil() {
        return perfil;
    }

    public boolean isSituacao() {
        return situacao;
    }

    public LocalDateTime getData_hora_criacao() {
        return data_hora_criacao;
    }

    public LocalDateTime getUltimo_login() {
        return ultimo_login;
    }

    
    
    //SET
    
    
    public void setId(Long id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setPerfil(Perfil perfil) {
        this.perfil = perfil;
    }

    public void setSituacao(boolean situacao) {
        this.situacao = situacao;
    }

    public void setData_hora_criacao(LocalDateTime data_hora_criacao) {
        this.data_hora_criacao = data_hora_criacao;
    }

    public void setUltimo_login(LocalDateTime ultimo_login) {
        this.ultimo_login = ultimo_login;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return Objects.equals(this.id, other.id);
    }
    
    public void reset(){
     this.situacao = true;
    }
    
    public void mudar_situacao(){
     this.situacao = !this.situacao;
    }
    
    
    
}
