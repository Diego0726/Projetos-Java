package modelo.dominio;

import java.math.BigDecimal;
import java.time.LocalDateTime;


public class Produto {
    
  private Long id;
  private String nome;
  private String descricao;
  private BigDecimal preco;
  private Integer quantidade;
  private Categoria categoria;
  private Usuario usuario;
  private LocalDateTime data_hora_criacao;

    //CONSTRUTOR
  
    public Produto() {
  
    }

    
    
    public Produto(Long id, String nome, String descricao, BigDecimal preco, Integer quantidade, Categoria categoria, Usuario usuario, LocalDateTime data_hora_criacao) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.quantidade = quantidade;
        this.categoria = categoria;
        this.usuario = usuario;
        this.data_hora_criacao = data_hora_criacao;
    }

    
    // GET
    
    public Long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public LocalDateTime getData_hora_criacao() {
        return data_hora_criacao;
    }

    
    
    //SET
    
    public void setId(Long id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setData_hora_criacao(LocalDateTime data_hora_criacao) {
        this.data_hora_criacao = data_hora_criacao;
    }
  
    

    
}
