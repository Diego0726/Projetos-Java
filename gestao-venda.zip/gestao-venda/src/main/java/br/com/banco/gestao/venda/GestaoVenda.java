package br.com.banco.gestao.venda;

/**
 * @author Diego Oliveira Barreto
 */
public class GestaoVenda {

    public static void main(String[] args) {
        
        
        
    }
}
